AI DROPSHIPPING HUB - PACHET PENTRU ÎNCĂRCARE

IMPORTANT:
- Acesta este un singur folder de proiect.
- Nu există un alt folder de proiect ascuns în interior.
- package.json este direct la rădăcina folderului.
- Folderul app conține aplicația.

Pentru Vercel, proiectul trebuie încărcat cu package.json la rădăcină.
După publicare, pentru AI real adaugă în Vercel variabila secretă:
OPENAI_API_KEY
Nu pune cheia secretă în fișierele publice.
