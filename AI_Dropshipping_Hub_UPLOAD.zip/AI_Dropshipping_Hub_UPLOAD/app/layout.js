export const metadata={title:"AI Dropshipping Hub",description:"Panel AI para dropshipping"};
export default function RootLayout({children}){return <html lang="ro"><body>{children}</body></html>}
