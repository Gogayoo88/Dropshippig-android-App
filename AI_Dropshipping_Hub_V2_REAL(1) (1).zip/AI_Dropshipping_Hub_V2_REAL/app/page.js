'use client';
import {useState} from 'react';
import './style.css';

const workers=[
 {id:'productos',icon:'🔥',name:'Cazador de Productos',desc:'Busca ideas de productos rentables y tendencias.'},
 {id:'proveedores',icon:'🏭',name:'Buscador de Proveedores',desc:'Investiga opciones de proveedores y criterios de selección.'},
 {id:'competencia',icon:'📊',name:'Analista de Competencia',desc:'Organiza qué revisar en tiendas, precios y posicionamiento.'},
 {id:'marketing',icon:'📣',name:'Especialista de Marketing',desc:'Genera ángulos de venta, anuncios y contenido.'},
 {id:'manager',icon:'🧠',name:'Manager AI',desc:'Resume el trabajo y propone los siguientes pasos.'},
 {id:'secretaria',icon:'📋',name:'Secretaría AI',desc:'Convierte resultados en tareas y prioridades.'}
];

export default function Home(){
 const [selected,setSelected]=useState(workers[0]); const [query,setQuery]=useState('');
 const [result,setResult]=useState('Selecciona un trabajador, escribe qué quieres investigar y pulsa TRABAJAR.');
 const [loading,setLoading]=useState(false);
 async function run(){
  setLoading(true); setResult('Trabajando...');
  try{
   const r=await fetch('/api/research',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({worker:selected.id,query})});
   const d=await r.json(); setResult(d.result||d.error||'Sin resultado');
  }catch(e){setResult('No se pudo completar la consulta. Revisa la conexión.');}
  setLoading(false);
 }
 return <main>
  <header><div><b>AI DROPSHIPPING HUB</b><span>V2 · Panel de trabajadores</span></div><span className="online">● ONLINE</span></header>
  <section className="hero"><h1>Tu equipo de trabajo AI</h1><p>Un panel sencillo para investigar productos, proveedores, competencia y marketing.</p></section>
  <div className="layout">
   <aside>{workers.map(w=><button key={w.id} className={selected.id===w.id?'active':''} onClick={()=>setSelected(w)}>
    <i>{w.icon}</i><span><strong>{w.name}</strong><small>{w.desc}</small></span></button>)}</aside>
   <section className="workspace">
    <div className="worker"><div className="avatar">{selected.icon}</div><div><h2>{selected.name}</h2><p>{selected.desc}</p></div></div>
    <label>¿Qué quieres que investigue?</label>
    <textarea value={query} onChange={e=>setQuery(e.target.value)} placeholder="Ej.: productos con potencial para España y Unión Europea, dropshipping sin almacén..."/>
    <button className="run" disabled={loading} onClick={run}>{loading?'TRABAJANDO...':'▶ TRABAJAR'}</button>
    <div className="result"><h3>Resultado</h3><pre>{result}</pre></div>
   </section>
  </div>
  <footer>Preparado para desplegar en Vercel · Diseño responsive para ordenador y Android</footer>
 </main>
}