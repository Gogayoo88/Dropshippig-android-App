# AI Dropshipping Hub V2 REAL

Proyecto web responsive preparado para Vercel.

## Subir
1. Descomprime el ZIP si la plataforma te pide una carpeta/repositorio.
2. Sube el proyecto.
3. En Vercel añade la variable de entorno `OPENAI_API_KEY` para activar investigación AI con búsqueda web.
4. Despliega.

Sin la clave, la interfaz funciona en MODO DEMO. La clave nunca debe escribirse dentro del código ni compartirse públicamente.

## Uso
Abre la aplicación, pulsa un trabajador, escribe la investigación y pulsa **TRABAJAR**.

Diseñado para funcionar bien en ordenador y navegador Android.
